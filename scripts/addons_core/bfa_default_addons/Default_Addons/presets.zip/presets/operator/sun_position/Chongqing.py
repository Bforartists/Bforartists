import bpy
sun_props = bpy.context.scene.sun_pos_properties

sun_props.UTC_zone = 8
sun_props.latitude = 29.558300
sun_props.longitude = 106.567000
