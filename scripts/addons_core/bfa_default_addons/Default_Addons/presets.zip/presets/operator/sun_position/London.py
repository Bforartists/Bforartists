import bpy
sun_props = bpy.context.scene.sun_pos_properties

sun_props.UTC_zone = 0
sun_props.latitude = 51.507200
sun_props.longitude = -0.127500
