import bpy
sun_props = bpy.context.scene.sun_pos_properties

sun_props.UTC_zone = -3
sun_props.latitude = -23.550000
sun_props.longitude = -46.633300
