import bpy
sun_props = bpy.context.scene.sun_pos_properties

sun_props.UTC_zone = 1
sun_props.latitude = -4.325000
sun_props.longitude = 15.322200
